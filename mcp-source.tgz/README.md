# Market & Filings MCP

A production-oriented, read-only MCP server built with Skybridge. It combines:

- **Yahoo Finance market data** through `yahoo-finance2`
- **Authoritative U.S. company filings and XBRL facts** through SEC EDGAR

## What it does

| Tool | Purpose |
|---|---|
| `open-market-filings` | Open a compact capability overview |
| `search-market-symbols` | Find stocks, ETFs, indices, funds, currencies, futures, and crypto symbols |
| `get-market-quotes` | Retrieve current quote snapshots for up to 25 symbols |
| `get-price-history` | Retrieve bounded historical OHLCV series |
| `get-company-profile` | Retrieve a concise business, market, valuation, financial, and analyst profile |
| `search-sec-companies` | Resolve company names and tickers to SEC CIKs |
| `list-sec-filings` | List recent filings with direct SEC source URLs |
| `get-sec-filing` | Extract bounded plain text or targeted excerpts from a filing |
| `get-sec-company-facts` | Retrieve standardized SEC XBRL company facts |

## Important limitations

- Yahoo Finance does not provide an official developer API. The connector uses the community-maintained `yahoo-finance2` package. Data may be delayed, incomplete, or change without notice.
- The filings provider currently covers **U.S. SEC EDGAR only**.
- `get-sec-filing` extracts HTML, XML, and plain text. It does not parse PDFs, images, exhibits, or scans in v1.
- This is a data connector, not investment advice or an exchange-grade trading feed.

## Prerequisites

- Node.js 24+
- npm

## Setup

```bash
npm install
cp .env.example .env
```

Set a compliant SEC user agent in `.env`:

```bash
SEC_USER_AGENT="YourCompany MarketFilingsMCP/0.1 your-email@example.com"
```

The SEC expects automated clients to identify the application and provide contact information. Do not run the production connector with the placeholder value.

## Run locally

```bash
npm run dev
```

This starts:

- MCP endpoint: `http://localhost:3000/mcp`
- Skybridge DevTools: `http://localhost:3000`

## Connect to ChatGPT or another remote MCP host

```bash
npm run dev:tunnel
```

Use the generated public `/mcp` URL when registering the connector.

## Validate

```bash
npm run typecheck
npm run build
npm run smoke:offline
npm run smoke
```

`npm run smoke:offline` validates the SEC mapping and extraction logic without network access.

The live `npm run smoke` test retrieves:

1. An AAPL quote from Yahoo Finance
2. Apple’s SEC CIK
3. Recent Apple 10-K/10-Q filings

## Deploy to Vercel

Import the repository into Vercel and configure:

```text
SEC_USER_AGENT=YourCompany MarketFilingsMCP/0.1 your-email@example.com
```

Vercel runs `npm run build` and publishes the MCP server at:

```text
https://your-project.vercel.app/mcp
```

The included `vercel.json` sets the install and build commands.

## Deploy to Alpic

```bash
npm run deploy
```

Configure `SEC_USER_AGENT` as a deployment environment variable before using the production endpoint.

## Example prompts

- “Find the Yahoo Finance symbols for Taiwan Semiconductor.”
- “Get current quotes for ASML, TSM, NVDA, and AVGO.”
- “Pull daily AAPL prices from 2025-01-01 to 2026-01-01.”
- “List Microsoft’s latest 10-K, 10-Q, and 8-K filings.”
- “Open Apple’s latest 10-K and find references to Greater China revenue.”
- “Pull the last eight reported values for Microsoft revenue, net income, assets, and free cash flow concepts from SEC XBRL.”

## Architecture

```text
MCP host
   |
Skybridge tool layer
   |-- Yahoo provider --> yahoo-finance2 --> Yahoo Finance
   |
   `-- SEC provider ----> data.sec.gov / sec.gov archives
```

A minimal overview view is included so Skybridge has a valid client entry point. Provider logic is separated from tool definitions so additional filing registries or paid market-data providers can be added without changing the MCP contract.

## Project files

```text
SPEC.md                 Product scope and design decisions
src/server.ts            MCP tool contracts and handlers
src/providers/yahoo.ts   Yahoo Finance provider
src/providers/sec.ts     SEC EDGAR provider, throttling, caching, extraction
scripts/smoke.ts         Live integration smoke test
scripts/offline-smoke.ts Deterministic provider and extraction smoke test
VALIDATION.md            Checks run and environment limitation
```
