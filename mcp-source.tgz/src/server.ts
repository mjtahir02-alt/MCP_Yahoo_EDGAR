import "dotenv/config";
import { McpServer } from "skybridge/server";
import { z } from "zod";
import {
  getCompanyProfile,
  getMarketQuotes,
  getPriceHistory,
  searchMarketSymbols,
} from "./providers/yahoo.js";
import {
  getSecCompanyFacts,
  getSecFiling,
  listSecFilings,
  searchSecCompanies,
} from "./providers/sec.js";

const readOnlyExternal = {
  readOnlyHint: true,
  destructiveHint: false,
  openWorldHint: true,
} as const;

const server = new McpServer(
  {
    name: "market-filings-mcp",
    version: "0.1.0",
  },
  { capabilities: {} },
)
  .registerTool(
    {
      name: "open-market-filings",
      title: "Open Market & Filings",
      description:
        "Open a compact overview of the market-data and SEC-filings capabilities available in this connector.",
      inputSchema: {},
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
      view: { component: "overview" },
      _meta: {
        "openai/toolInvocation/invoking": "Opening connector overview…",
        "openai/toolInvocation/invoked": "Connector overview opened",
      },
    },
    async () => ({
      content: "Opened the Market & Filings connector overview.",
      structuredContent: {
        title: "Market & Filings",
        description:
          "Research listed securities, inspect SEC filings, search within primary documents, and retrieve standardized XBRL facts.",
        capabilities: [
          {
            name: "Market data",
            description: "Symbol search, quote snapshots, historical OHLCV prices, and concise company profiles.",
          },
          {
            name: "SEC filings",
            description: "Registrant search, filing lists, direct source links, and bounded document extraction.",
          },
          {
            name: "Financial facts",
            description: "Standardized SEC XBRL facts with reporting periods, forms, and accession numbers.",
          },
        ],
        dataSourceNote:
          "SEC EDGAR is authoritative. Yahoo Finance access is unofficial and should not be treated as an exchange-grade real-time feed.",
      },
    }),
  )
  .registerTool(
    {
      name: "search-market-symbols",
      title: "Search Market Symbols",
      description:
        "Search Yahoo Finance for stocks, ETFs, indices, currencies, futures, funds, and cryptocurrencies by company name, instrument name, or ticker.",
      inputSchema: {
        query: z.string().min(1).describe("Company name, instrument name, or ticker to search for."),
        limit: z.number().int().min(1).max(25).default(10),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Searching market symbols…",
        "openai/toolInvocation/invoked": "Market symbol search complete",
      },
    },
    async ({ query, limit }) => {
      const results = await searchMarketSymbols(query, limit);
      return {
        content: `Found ${results.length} Yahoo Finance symbols for “${query}”.`,
        structuredContent: {
          query,
          results,
          provider: "Yahoo Finance via yahoo-finance2 (unofficial)",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "get-market-quotes",
      title: "Get Market Quotes",
      description:
        "Retrieve current quote snapshots for one or more Yahoo Finance symbols, including price, daily movement, volume, market cap, valuation fields, and market timestamp.",
      inputSchema: {
        symbols: z
          .array(z.string().min(1))
          .min(1)
          .max(25)
          .describe("Yahoo Finance symbols, for example AAPL, MSFT, BTC-USD, ASML.AS."),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Retrieving market quotes…",
        "openai/toolInvocation/invoked": "Market quotes retrieved",
      },
    },
    async ({ symbols }) => {
      const normalized = [...new Set(symbols.map((symbol) => symbol.trim().toUpperCase()))];
      const quotes = await getMarketQuotes(normalized);
      return {
        content: `Retrieved ${quotes.length} quote snapshots. Prices may be delayed and are not an exchange-grade real-time feed.`,
        structuredContent: {
          quotes,
          provider: "Yahoo Finance via yahoo-finance2 (unofficial)",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "get-price-history",
      title: "Get Price History",
      description:
        "Retrieve historical OHLCV price data for a Yahoo Finance symbol over a specified date range and interval. Use daily or longer intervals for long histories; intraday availability is limited upstream.",
      inputSchema: {
        symbol: z.string().min(1),
        period1: z.string().describe("Inclusive start date in YYYY-MM-DD format."),
        period2: z.string().optional().describe("Optional exclusive end date in YYYY-MM-DD format."),
        interval: z
          .enum(["1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h", "1d", "5d", "1wk", "1mo", "3mo"])
          .default("1d"),
        includeEvents: z.boolean().default(false).describe("Include dividends, splits, and capital gains where available."),
        maxPoints: z.number().int().min(1).max(5000).default(1000),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Retrieving price history…",
        "openai/toolInvocation/invoked": "Price history retrieved",
      },
    },
    async ({ symbol, period1, period2, interval, includeEvents, maxPoints }) => {
      const result = await getPriceHistory({
        symbol: symbol.trim().toUpperCase(),
        period1,
        period2,
        interval,
        includeEvents,
      });
      const totalPoints = result.prices.length;
      const prices = result.prices.slice(-maxPoints);
      return {
        content: `Retrieved ${prices.length} of ${totalPoints} available ${interval} price points for ${symbol.toUpperCase()}.`,
        structuredContent: {
          ...result,
          prices,
          totalPoints,
          returnedPoints: prices.length,
          provider: "Yahoo Finance via yahoo-finance2 (unofficial)",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "get-company-profile",
      title: "Get Company Profile",
      description:
        "Retrieve a concise Yahoo Finance company profile with business description, market snapshot, valuation, financial metrics, analyst targets, and calendar fields.",
      inputSchema: {
        symbol: z.string().min(1).describe("Yahoo Finance equity symbol."),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Retrieving company profile…",
        "openai/toolInvocation/invoked": "Company profile retrieved",
      },
    },
    async ({ symbol }) => {
      const profile = await getCompanyProfile(symbol.trim().toUpperCase());
      return {
        content: `Retrieved a company profile for ${symbol.toUpperCase()}.`,
        structuredContent: {
          profile,
          provider: "Yahoo Finance via yahoo-finance2 (unofficial)",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "search-sec-companies",
      title: "Search SEC Companies",
      description:
        "Search the SEC company ticker list for U.S. EDGAR registrants by ticker or company name and return canonical CIK identifiers.",
      inputSchema: {
        query: z.string().min(1),
        limit: z.number().int().min(1).max(25).default(10),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Searching SEC registrants…",
        "openai/toolInvocation/invoked": "SEC registrant search complete",
      },
    },
    async ({ query, limit }) => {
      const companies = await searchSecCompanies(query, limit);
      return {
        content: `Found ${companies.length} SEC registrants for “${query}”.`,
        structuredContent: {
          query,
          companies,
          provider: "U.S. SEC EDGAR",
          source: "https://www.sec.gov/files/company_tickers.json",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "list-sec-filings",
      title: "List SEC Filings",
      description:
        "List recent SEC EDGAR filings for a ticker, CIK, or unambiguous company name. Filter by form type and filing date. Returns direct filing and index URLs.",
      inputSchema: {
        identifier: z.string().min(1).describe("Ticker, 1-10 digit CIK, or unambiguous registrant name."),
        forms: z
          .array(z.string().min(1))
          .max(20)
          .optional()
          .describe("Optional exact SEC forms, for example 10-K, 10-Q, 8-K, 20-F, 6-K."),
        startDate: z.string().optional().describe("Optional inclusive filing date in YYYY-MM-DD format."),
        endDate: z.string().optional().describe("Optional inclusive filing date in YYYY-MM-DD format."),
        limit: z.number().int().min(1).max(200).default(20),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Retrieving SEC filings…",
        "openai/toolInvocation/invoked": "SEC filings retrieved",
      },
    },
    async ({ identifier, forms, startDate, endDate, limit }) => {
      const result = await listSecFilings({ identifier, forms, startDate, endDate, limit });
      return {
        content: `Retrieved ${result.filings.length} SEC filings for ${result.company.name}.`,
        structuredContent: {
          ...result,
          provider: "U.S. SEC EDGAR",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "get-sec-filing",
      title: "Get SEC Filing",
      description:
        "Retrieve the primary document for a specific SEC accession number and convert HTML/XML to bounded plain text. Optionally search within the filing and return focused excerpts. Use list-sec-filings first to obtain the accession number.",
      inputSchema: {
        identifier: z.string().min(1).describe("Ticker, CIK, or unambiguous registrant name."),
        accessionNumber: z.string().min(8).describe("SEC accession number, with or without hyphens."),
        searchTerm: z
          .string()
          .min(2)
          .optional()
          .describe("Optional case-insensitive term or phrase. Returns excerpts around matches instead of a sequential chunk."),
        startCharacter: z
          .number()
          .int()
          .min(0)
          .default(0)
          .describe("Start offset for sequential reading. Ignored when searchTerm is supplied."),
        maxCharacters: z.number().int().min(1000).max(50_000).default(20_000),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Retrieving SEC filing…",
        "openai/toolInvocation/invoked": "SEC filing retrieved",
      },
    },
    async ({ identifier, accessionNumber, searchTerm, startCharacter, maxCharacters }) => {
      const result = await getSecFiling({
        identifier,
        accessionNumber,
        searchTerm,
        startCharacter,
        maxCharacters,
      });
      return {
        content: searchTerm
          ? `Retrieved bounded filing excerpts for “${searchTerm}”.`
          : `Retrieved a bounded filing text segment for accession ${accessionNumber}.`,
        structuredContent: {
          ...result,
          provider: "U.S. SEC EDGAR",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  )
  .registerTool(
    {
      name: "get-sec-company-facts",
      title: "Get SEC Company Facts",
      description:
        "Retrieve standardized XBRL facts directly from the SEC Company Facts API for selected taxonomy concepts, with filing periods, forms, accession numbers, and source metadata.",
      inputSchema: {
        identifier: z.string().min(1).describe("Ticker, CIK, or unambiguous registrant name."),
        taxonomy: z.string().min(1).default("us-gaap").describe("XBRL taxonomy such as us-gaap or ifrs-full."),
        concepts: z
          .array(z.string().min(1))
          .min(1)
          .max(30)
          .default([
            "Revenues",
            "RevenueFromContractWithCustomerExcludingAssessedTax",
            "NetIncomeLoss",
            "Assets",
            "Liabilities",
            "StockholdersEquity",
            "CashAndCashEquivalentsAtCarryingValue",
          ])
          .describe("Exact XBRL concept names."),
        forms: z
          .array(z.string().min(1))
          .max(20)
          .optional()
          .default(["10-K", "10-Q"]),
        limitPerConcept: z.number().int().min(1).max(50).default(12),
      },
      annotations: readOnlyExternal,
      _meta: {
        "openai/toolInvocation/invoking": "Retrieving SEC company facts…",
        "openai/toolInvocation/invoked": "SEC company facts retrieved",
      },
    },
    async ({ identifier, taxonomy, concepts, forms, limitPerConcept }) => {
      const result = await getSecCompanyFacts({
        identifier,
        taxonomy,
        concepts,
        forms,
        limitPerConcept,
      });
      const found = result.facts.filter((fact) => fact.found).length;
      return {
        content: `Retrieved ${found} of ${concepts.length} requested ${taxonomy} concepts for ${result.company.name}.`,
        structuredContent: {
          ...result,
          provider: "U.S. SEC EDGAR",
          retrievedAt: new Date().toISOString(),
        },
      };
    },
  );

export default await server.run();
export type AppType = typeof server;
