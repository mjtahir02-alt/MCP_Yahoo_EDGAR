export default function Home() {
  return (
    <main style={{ fontFamily: "system-ui, sans-serif", maxWidth: 760, margin: "64px auto", padding: 24 }}>
      <h1>Yahoo Finance & SEC EDGAR MCP</h1>
      <p>Remote MCP server for public market data and U.S. company filings.</p>
      <p><strong>MCP endpoint:</strong> <code>/mcp</code></p>
      <p>Yahoo Finance data is unofficial. SEC filing data comes from official EDGAR endpoints.</p>
    </main>
  );
}
