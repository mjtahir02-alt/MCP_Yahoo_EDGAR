import { createMcpHandler } from "mcp-handler";
import { z } from "zod";
import { textResult, unixSeconds } from "../../lib/common";
import { getYahooHistory, getYahooQuotes, searchYahoo } from "../../lib/yahoo";
import { companyFacts, getFiling, listFilings, searchSec } from "../../lib/sec";

export const runtime = "nodejs";
export const maxDuration = 60;
const USER_AGENT = process.env.SEC_USER_AGENT ?? "MCPYahooEDGAR/0.2 mjtahir02@gmail.com";
const stamp = () => new Date().toISOString();

const handler = createMcpHandler(
  (server) => {
    server.tool("search-market-symbols", "Search Yahoo Finance for market symbols.", {
      query: z.string().min(1), limit: z.number().int().min(1).max(25).default(10),
    }, async ({ query, limit }) => {
      const quotes = await searchYahoo(query, limit);
      return textResult({ query, quotes, provider: "Yahoo Finance (unofficial)", retrievedAt: stamp() }, `Found ${quotes.length} symbols.`);
    });

    server.tool("get-market-quotes", "Retrieve current Yahoo Finance snapshots.", {
      symbols: z.array(z.string().min(1)).min(1).max(20),
    }, async ({ symbols }) => {
      const quotes = await getYahooQuotes(symbols);
      return textResult({ quotes, provider: "Yahoo Finance chart API (unofficial)", retrievedAt: stamp() }, `Retrieved ${quotes.length} snapshots.`);
    });

    server.tool("get-price-history", "Retrieve historical Yahoo Finance OHLCV data.", {
      symbol: z.string().min(1),
      period1: z.string(),
      period2: z.string().optional(),
      interval: z.enum(["1d", "5d", "1wk", "1mo", "3mo"]).default("1d"),
      maxPoints: z.number().int().min(1).max(2000).default(500),
    }, async ({ symbol, period1, period2, interval, maxPoints }) => {
      const result = await getYahooHistory({ symbol, period1: unixSeconds(period1), period2: period2 ? unixSeconds(period2) : Math.floor(Date.now() / 1000), interval, maxPoints });
      return textResult({ ...result, returnedPoints: result.prices.length, provider: "Yahoo Finance chart API (unofficial)", retrievedAt: stamp() }, `Retrieved ${result.prices.length} price points.`);
    });

    server.tool("search-sec-companies", "Search SEC registrants and return CIKs.", {
      query: z.string().min(1), limit: z.number().int().min(1).max(25).default(10),
    }, async ({ query, limit }) => {
      const companies = await searchSec(query, limit, USER_AGENT);
      return textResult({ query, companies, provider: "U.S. SEC EDGAR", retrievedAt: stamp() }, `Found ${companies.length} registrants.`);
    });

    server.tool("list-sec-filings", "List recent SEC filings for a company.", {
      identifier: z.string().min(1),
      forms: z.array(z.string().min(1)).max(20).optional(),
      startDate: z.string().optional(), endDate: z.string().optional(),
      limit: z.number().int().min(1).max(200).default(20),
    }, async ({ identifier, forms, startDate, endDate, limit }) => {
      const result = await listFilings({ identifier, forms, startDate, endDate, limit, userAgent: USER_AGENT });
      return textResult({ ...result, provider: "U.S. SEC EDGAR", retrievedAt: stamp() }, `Retrieved ${result.filings.length} filings.`);
    });

    server.tool("get-sec-filing", "Retrieve bounded text or excerpts from a recent SEC filing.", {
      identifier: z.string().min(1), accessionNumber: z.string().min(8),
      searchTerm: z.string().min(2).optional(),
      startCharacter: z.number().int().min(0).default(0),
      maxCharacters: z.number().int().min(1000).max(50000).default(20000),
    }, async ({ identifier, accessionNumber, searchTerm, startCharacter, maxCharacters }) => {
      const result = await getFiling({ identifier, accessionNumber, searchTerm, startCharacter, maxCharacters, userAgent: USER_AGENT });
      return textResult({ ...result, provider: "U.S. SEC EDGAR", retrievedAt: stamp() }, `Retrieved SEC filing ${accessionNumber}.`);
    });

    server.tool("get-sec-company-facts", "Retrieve standardized SEC XBRL company facts.", {
      identifier: z.string().min(1), taxonomy: z.string().default("us-gaap"),
      concepts: z.array(z.string()).min(1).max(30).default(["Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax", "NetIncomeLoss", "Assets", "Liabilities", "StockholdersEquity", "CashAndCashEquivalentsAtCarryingValue"]),
      forms: z.array(z.string()).max(20).default(["10-K", "10-Q"]),
      limitPerConcept: z.number().int().min(1).max(50).default(12),
    }, async ({ identifier, taxonomy, concepts, forms, limitPerConcept }) => {
      const result = await companyFacts({ identifier, taxonomy, concepts, forms, limitPerConcept, userAgent: USER_AGENT });
      return textResult({ ...result, provider: "U.S. SEC EDGAR", retrievedAt: stamp() }, `Retrieved ${result.facts.filter((x) => x.found).length} XBRL concepts.`);
    });
  },
  {},
  { basePath: "" },
);

export { handler as GET, handler as POST, handler as DELETE };
