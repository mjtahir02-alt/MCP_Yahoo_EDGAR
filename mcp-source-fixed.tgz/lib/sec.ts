import { fetchJson, fetchText, type AnyRecord } from "./common";

export type SecCompany = { cik: string; ticker: string; name: string };
let cache: { expires: number; rows: SecCompany[] } | undefined;

async function loadCompanies(userAgent: string) {
  if (cache && cache.expires > Date.now()) return cache.rows;
  const payload = await fetchJson("https://www.sec.gov/files/company_tickers.json", "SEC EDGAR", userAgent);
  const rows = Object.values(payload).map((item: any) => ({
    cik: String(item.cik_str).padStart(10, "0"),
    ticker: String(item.ticker ?? "").toUpperCase(),
    name: String(item.title ?? ""),
  }));
  cache = { rows, expires: Date.now() + 6 * 60 * 60 * 1000 };
  return rows;
}

function normalize(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

export async function searchSec(query: string, limit: number, userAgent: string) {
  const rows = await loadCompanies(userAgent);
  const q = normalize(query);
  const ticker = query.trim().toUpperCase();
  return rows
    .filter((row) => row.ticker.includes(ticker) || normalize(row.name).includes(q))
    .sort((a, b) => {
      const ae = a.ticker === ticker || normalize(a.name) === q ? 0 : 1;
      const be = b.ticker === ticker || normalize(b.name) === q ? 0 : 1;
      return ae - be || a.name.localeCompare(b.name);
    })
    .slice(0, limit);
}

export async function resolveSec(identifier: string, userAgent: string): Promise<SecCompany> {
  const value = identifier.trim();
  const rows = await loadCompanies(userAgent);
  if (/^\d{1,10}$/.test(value)) {
    const cik = value.padStart(10, "0");
    return rows.find((row) => row.cik === cik) ?? { cik, ticker: "", name: `CIK ${cik}` };
  }
  const ticker = value.toUpperCase();
  const tickerMatch = rows.find((row) => row.ticker === ticker);
  if (tickerMatch) return tickerMatch;
  const q = normalize(value);
  const exact = rows.find((row) => normalize(row.name) === q);
  if (exact) return exact;
  const candidates = rows.filter((row) => normalize(row.name).includes(q)).slice(0, 5);
  if (candidates.length === 1) return candidates[0];
  if (!candidates.length) throw new Error(`No SEC registrant found for “${identifier}”`);
  throw new Error(`Ambiguous company. Try a ticker or CIK: ${candidates.map((x) => `${x.ticker} — ${x.name}`).join("; ")}`);
}

async function submissions(company: SecCompany, userAgent: string) {
  return fetchJson(`https://data.sec.gov/submissions/CIK${company.cik}.json`, "SEC EDGAR", userAgent);
}

function recent(payload: AnyRecord) {
  const data = payload?.filings?.recent ?? {};
  const accessions: string[] = data.accessionNumber ?? [];
  return accessions.map((accessionNumber, i) => ({
    accessionNumber,
    filingDate: data.filingDate?.[i] ?? null,
    reportDate: data.reportDate?.[i] ?? null,
    acceptanceDateTime: data.acceptanceDateTime?.[i] ?? null,
    form: data.form?.[i] ?? null,
    primaryDocument: data.primaryDocument?.[i] ?? null,
    primaryDocDescription: data.primaryDocDescription?.[i] ?? null,
    fileNumber: data.fileNumber?.[i] ?? null,
    items: data.items?.[i] ?? null,
  }));
}

function filingUrl(company: SecCompany, accession: string, document: string) {
  return `https://www.sec.gov/Archives/edgar/data/${Number(company.cik)}/${accession.replace(/-/g, "")}/${document}`;
}

export async function listFilings(input: {
  identifier: string;
  forms?: string[];
  startDate?: string;
  endDate?: string;
  limit: number;
  userAgent: string;
}) {
  const company = await resolveSec(input.identifier, input.userAgent);
  const payload = await submissions(company, input.userAgent);
  const formSet = input.forms?.length ? new Set(input.forms.map((x) => x.toUpperCase())) : null;
  const filings = recent(payload)
    .filter((x) => !formSet || formSet.has(String(x.form).toUpperCase()))
    .filter((x) => !input.startDate || String(x.filingDate) >= input.startDate)
    .filter((x) => !input.endDate || String(x.filingDate) <= input.endDate)
    .slice(0, input.limit)
    .map((x) => ({
      ...x,
      filingUrl: x.primaryDocument ? filingUrl(company, x.accessionNumber, x.primaryDocument) : null,
      indexUrl: `https://www.sec.gov/Archives/edgar/data/${Number(company.cik)}/${x.accessionNumber.replace(/-/g, "")}/`,
    }));
  return { company: { ...company, name: payload.name ?? company.name }, filings };
}

function decodeEntities(value: string) {
  const named: Record<string, string> = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  return value
    .replace(/&([a-z]+);/gi, (all, key) => named[key.toLowerCase()] ?? all)
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)));
}

function htmlToText(html: string) {
  return decodeEntities(
    html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/(p|div|section|article|tr|li|h[1-6])>/gi, "\n")
      .replace(/<[^>]+>/g, " "),
  ).replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n[ \t]+/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

export async function getFiling(input: {
  identifier: string;
  accessionNumber: string;
  searchTerm?: string;
  startCharacter: number;
  maxCharacters: number;
  userAgent: string;
}) {
  const company = await resolveSec(input.identifier, input.userAgent);
  const payload = await submissions(company, input.userAgent);
  const filing = recent(payload).find((x) => x.accessionNumber.replace(/-/g, "") === input.accessionNumber.replace(/-/g, ""));
  if (!filing?.primaryDocument) throw new Error("Accession number not found in recent SEC submissions.");
  const url = filingUrl(company, filing.accessionNumber, filing.primaryDocument);
  const text = htmlToText(await fetchText(url, input.userAgent));
  if (input.searchTerm) {
    const lower = text.toLowerCase();
    const needle = input.searchTerm.toLowerCase();
    const excerpts: Array<{ start: number; end: number; text: string }> = [];
    let cursor = 0;
    while (excerpts.length < 10) {
      const match = lower.indexOf(needle, cursor);
      if (match < 0) break;
      const start = Math.max(0, match - Math.floor(input.maxCharacters / 4));
      const end = Math.min(text.length, match + needle.length + Math.floor(input.maxCharacters / 4));
      excerpts.push({ start, end, text: text.slice(start, end) });
      cursor = match + needle.length;
    }
    return { company, filing, url, searchTerm: input.searchTerm, matchesReturned: excerpts.length, excerpts };
  }
  const end = Math.min(text.length, input.startCharacter + input.maxCharacters);
  return { company, filing, url, startCharacter: input.startCharacter, endCharacter: end, totalCharacters: text.length, text: text.slice(input.startCharacter, end) };
}

export async function companyFacts(input: {
  identifier: string;
  taxonomy: string;
  concepts: string[];
  forms: string[];
  limitPerConcept: number;
  userAgent: string;
}) {
  const company = await resolveSec(input.identifier, input.userAgent);
  const payload = await fetchJson(`https://data.sec.gov/api/xbrl/companyfacts/CIK${company.cik}.json`, "SEC EDGAR", input.userAgent);
  const formSet = new Set(input.forms.map((x) => x.toUpperCase()));
  const facts = input.concepts.map((concept) => {
    const fact = payload?.facts?.[input.taxonomy]?.[concept];
    if (!fact) return { concept, found: false, units: {} };
    const units = Object.fromEntries(Object.entries(fact.units ?? {}).map(([unit, entries]) => [
      unit,
      (entries as AnyRecord[]).filter((e) => !e.form || formSet.has(String(e.form).toUpperCase())).slice(-input.limitPerConcept),
    ]));
    return { concept, found: true, label: fact.label, description: fact.description, units };
  });
  return { company: { ...company, name: payload.entityName ?? company.name }, taxonomy: input.taxonomy, facts };
}
