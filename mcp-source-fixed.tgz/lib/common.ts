export type AnyRecord = Record<string, any>;

export function textResult(value: unknown, summary?: string) {
  const body = JSON.stringify(value, null, 2);
  return {
    content: [{ type: "text" as const, text: summary ? `${summary}\n\n${body}` : body }],
  };
}

export async function fetchJson(
  url: string,
  provider: "Yahoo Finance" | "SEC EDGAR",
  secUserAgent: string,
) {
  const response = await fetch(url, {
    headers: {
      Accept: "application/json,text/plain,*/*",
      "User-Agent": provider === "SEC EDGAR" ? secUserAgent : "Mozilla/5.0 MCPYahooEDGAR/0.2",
    },
    signal: AbortSignal.timeout(25_000),
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`${provider} request failed: ${response.status} ${response.statusText}`);
  return (await response.json()) as AnyRecord;
}

export async function fetchText(url: string, secUserAgent: string) {
  const response = await fetch(url, {
    headers: {
      Accept: "text/html,application/xhtml+xml,text/plain,*/*",
      "User-Agent": secUserAgent,
    },
    signal: AbortSignal.timeout(25_000),
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`SEC EDGAR request failed: ${response.status} ${response.statusText}`);
  return response.text();
}

export function cleanNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

export function unixSeconds(value: string) {
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new Error(`Invalid date: ${value}`);
  return Math.floor(parsed / 1000);
}
