import { cleanNumber, fetchJson, type AnyRecord } from "./common";

async function yahooChart(symbol: string, params: URLSearchParams) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.toUpperCase())}?${params}`;
  const payload = await fetchJson(url, "Yahoo Finance", "");
  const error = payload?.chart?.error;
  if (error) throw new Error(`Yahoo Finance: ${error.description ?? error.code}`);
  const result = payload?.chart?.result?.[0];
  if (!result) throw new Error(`No Yahoo Finance data returned for ${symbol}`);
  return result as AnyRecord;
}

export async function searchYahoo(query: string, limit: number) {
  const url = new URL("https://query2.finance.yahoo.com/v1/finance/search");
  url.searchParams.set("q", query);
  url.searchParams.set("quotesCount", String(limit));
  url.searchParams.set("newsCount", "0");
  url.searchParams.set("enableFuzzyQuery", "true");
  const payload = await fetchJson(url.toString(), "Yahoo Finance", "");
  return (payload.quotes ?? []).slice(0, limit).map((item: AnyRecord) => ({
    symbol: item.symbol,
    name: item.longname ?? item.shortname,
    quoteType: item.quoteType,
    exchange: item.exchange,
    exchangeDisplay: item.exchDisp,
    sector: item.sector,
    industry: item.industry,
  }));
}

export async function getYahooQuotes(symbols: string[]) {
  return Promise.all(
    symbols.map(async (input) => {
      const symbol = input.trim().toUpperCase();
      const result = await yahooChart(
        symbol,
        new URLSearchParams({ interval: "1d", range: "5d", events: "div,splits" }),
      );
      const meta = result.meta ?? {};
      const timestamps: number[] = result.timestamp ?? [];
      const quote = result.indicators?.quote?.[0] ?? {};
      const last = Math.max(0, timestamps.length - 1);
      return {
        symbol,
        name: meta.longName ?? meta.shortName ?? null,
        exchange: meta.fullExchangeName ?? meta.exchangeName ?? null,
        currency: meta.currency ?? null,
        marketState: meta.marketState ?? null,
        regularMarketPrice: cleanNumber(meta.regularMarketPrice),
        previousClose: cleanNumber(meta.chartPreviousClose ?? meta.previousClose),
        regularMarketTime: meta.regularMarketTime
          ? new Date(meta.regularMarketTime * 1000).toISOString()
          : null,
        dayOpen: cleanNumber(quote.open?.[last]),
        dayHigh: cleanNumber(quote.high?.[last]),
        dayLow: cleanNumber(quote.low?.[last]),
        dayClose: cleanNumber(quote.close?.[last]),
        volume: cleanNumber(quote.volume?.[last]),
        fiftyTwoWeekHigh: cleanNumber(meta.fiftyTwoWeekHigh),
        fiftyTwoWeekLow: cleanNumber(meta.fiftyTwoWeekLow),
      };
    }),
  );
}

export async function getYahooHistory(input: {
  symbol: string;
  period1: number;
  period2: number;
  interval: string;
  maxPoints: number;
}) {
  const params = new URLSearchParams({
    period1: String(input.period1),
    period2: String(input.period2),
    interval: input.interval,
    events: "div,splits,capitalGains",
  });
  const result = await yahooChart(input.symbol, params);
  const timestamps: number[] = result.timestamp ?? [];
  const quote = result.indicators?.quote?.[0] ?? {};
  const adjusted = result.indicators?.adjclose?.[0]?.adjclose ?? [];
  const points = timestamps.map((timestamp, index) => ({
    date: new Date(timestamp * 1000).toISOString(),
    open: cleanNumber(quote.open?.[index]),
    high: cleanNumber(quote.high?.[index]),
    low: cleanNumber(quote.low?.[index]),
    close: cleanNumber(quote.close?.[index]),
    adjustedClose: cleanNumber(adjusted?.[index]),
    volume: cleanNumber(quote.volume?.[index]),
  }));
  return {
    symbol: input.symbol.toUpperCase(),
    meta: result.meta ?? {},
    totalPoints: points.length,
    prices: points.slice(-input.maxPoints),
    events: result.events ?? null,
  };
}
